
# Makaziwe Happy Mtsweni - Personal Portfolio

## Project Description

This is a personal portfolio website developed to introduce
Makaziwe Happy Mtsweni as an IT Software Development student.

The website presents educational background, technical skills,
academic projects, business involvement and contact information.

## Website Pages

1. Home - Introduction and professional overview.
2. About - Educational background and career goals.
3. Skills - Technical and professional skills.
4. Projects - Academic and practical projects.
5. Business - Frozen Trust business profile.
6. Contact - Contact information and enquiry form.

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Visual Studio Code
- GitHub

## Main Features

- Responsive website layout.
- Navigation between six webpages.
- Mobile navigation menu.
- Contact form validation.
- Email draft preparation.

## How to Run the Website

1. Download or copy the project folder.
2. Open the folder in Visual Studio Code.
3. Open index.html.
4. Use Live Server to preview the website.

## Project Purpose

The purpose of this portfolio is to demonstrate my learning,
technical development and practical application of Information
Technology concepts.
